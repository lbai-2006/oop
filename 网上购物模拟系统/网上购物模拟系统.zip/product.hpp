#pragma once
#ifndef PRODUCT_HPP
#define PRODUCT_HPP

#include<iostream>

using namespace std;

class Product{
    friend class Administrator; //����Ա��Ҫ�޸���Ʒ��Ϣ
    private:
        string product_class;
        string product_name;
        double product_price;
        int product_stock;
        string product_description;
    public:
        Product(string product_class, string product_name, double product_price, int product_stock, string product_description);
        //~Product();
        void Display();
        
        // Getter �������ṩֻ�����ʣ���֤���ݰ�ȫ
        string GetProductClass() const { return product_class; }
        string GetProductName() const { return product_name; }
        double GetProductPrice() const { return product_price; }
        int GetProductStock() const { return product_stock; }
        string GetProductDescription() const { return product_description; }
        //�޸���Ʒ���
        void ModifyProductStock(int quantity);
    }; 

#endif